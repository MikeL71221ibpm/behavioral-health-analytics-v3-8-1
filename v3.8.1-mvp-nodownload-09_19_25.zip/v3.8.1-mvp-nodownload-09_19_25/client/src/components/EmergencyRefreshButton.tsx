import React from 'react';
import { Button } from '@/components/ui/button';
import { RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function EmergencyRefreshButton() {
  const { toast } = useToast();

  const handleEmergencyRefresh = () => {
    // Check if there are stuck loading states that can be cleared without full reset
    const hasStuckLoading = document.querySelector('[data-loading-spinner]') !== null;
    
    if (hasStuckLoading) {
      if (window.confirm('Clear stuck loading messages? (No data will be lost)')) {
        // Emit custom event to clear loading states
        window.dispatchEvent(new CustomEvent('clearStuckLoading'));
        toast({
          title: "Loading Cleared",
          description: "Stuck loading messages have been cleared.",
          duration: 3000
        });
        return;
      }
    }
    
    // Original full reset option - same as v3.7.14
    if (window.confirm('This will clear all data and reset the system. Continue?')) {
      console.log('🚨 Refresh - Starting reset request...');
      console.log('🚨 Refresh - Current URL:', window.location.href);
      
      fetch('/api/emergency-reset-bypass', { 
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json'
        }
      })
        .then(res => {
          console.log('🚨 Refresh - Response status:', res.status);
          console.log('🚨 Refresh - Response OK:', res.ok);
          
          if (!res.ok) {
            throw new Error(`HTTP ${res.status}: ${res.statusText}`);
          }
          
          return res.json();
        })
        .then(result => {
          console.log('🚨 Refresh - Success:', result);
          toast({
            title: "Reset Complete",
            description: "All data has been cleared successfully.",
            duration: 3000
          });
          window.location.reload();
        })
        .catch(err => {
          console.error('🚨 Refresh - Failed:', err);
          toast({
            title: "Reset Failed",
            description: err.message || "An error occurred during reset",
            variant: "destructive",
            duration: 5000
          });
        });
    }
  };

  return (
    <Button
      variant="destructive"
      size="sm"
      onClick={handleEmergencyRefresh}
      className="flex items-center gap-2"
    >
      <RefreshCw className="h-4 w-4" />
      Clear Stuck Processing
    </Button>
  );
}