import React, { useState, useCallback, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { ResponsiveBar } from '@nivo/bar';
import { ResponsivePie } from '@nivo/pie';
import { ResponsiveHeatMap } from '@nivo/heatmap';
import { ResponsiveCirclePacking } from '@nivo/circle-packing';
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { Check, ChevronsUpDown, Download, Maximize, Loader2, FileQuestion, Palette } from "lucide-react";

// Define types for chart data
interface ChartDataItem {
  id: string;
  value: number;
  percentage?: number;
  [key: string]: string | number | undefined;
}

// Define type for color theme
interface ColorThemePreset {
  name: string;
  saturation?: number;
  lightness?: number;
  alpha?: number;
  isCustomPalette?: boolean;
  colors?: string[];
}

// Color themes - these define vibrancy of the colors, not the individual colors themselves
const COLOR_THEMES: Record<string, ColorThemePreset> = {
  // COLOR INTENSITY THEMES
  vivid: {
    name: "Vivid Colors",
    saturation: 100,  // Increased from 90 to 100 for more vivid colors
    lightness: 55,    // Decreased from 60 to 55 for better contrast
    alpha: 1,        // Fully opaque
  },
  
  pastel: {
    name: "Pastel Colors",
    saturation: 70,  // Increased from 60 to 70 for better differentiation
    lightness: 75,   // Decreased from 80 to 75 for better contrast
    alpha: 0.9,      // Increased opacity from 0.8 to 0.9
  },
  
  muted: {
    name: "Muted Colors",
    saturation: 50,  // Increased from 40 to 50 for better differentiation
    lightness: 45,   // Decreased from 50 to 45 for better contrast
    alpha: 0.95,     // Increased opacity from 0.9 to 0.95
  },
  
  dark: {
    name: "Dark Colors",
    saturation: 85,  // Increased from 70 to 85 for better differentiation
    lightness: 35,   // Increased from 30 to 35 for better visibility
    alpha: 1,        // Fully opaque
  },
  
  light: {
    name: "Light Colors",
    saturation: 60,  // Increased from 50 to 60 for better differentiation
    lightness: 65,   // Decreased from 70 to 65 for better contrast
    alpha: 0.9,      // Increased opacity from 0.85 to 0.9
  },
  
  // Viridis - colorblind friendly theme based on the matplotlib viridis palette
  // Enhanced with more steps for better differentiation
  viridis: {
    name: "Viridis (Colorblind Friendly)",
    isCustomPalette: true,
    colors: [
      '#440154', // Dark purple
      '#482677', // Deep purple
      '#404688', // Deep blue
      '#33638D', // Medium blue
      '#27808E', // Teal
      '#1FA187', // Blue-green
      '#49B97C', // Green
      '#6ECE58', // Light green
      '#A2DB34', // Yellow-green
      '#E0DD12', // Yellow
      '#FDE725'  // Bright yellow
    ]
  }
};

interface PopulationHealthChartsProps {
  data?: any;
  isLoading?: boolean;
}

export default function PopulationHealthCharts({ 
  data, 
  isLoading = false 
}: PopulationHealthChartsProps) {
  const [categoryCount, setCategoryCount] = useState<number>(10);
  
  // Theme selector state
  const [currentTheme, setCurrentTheme] = useState<string>("vivid");
  const [colorSettings, setColorSettings] = useState<ColorThemePreset>(COLOR_THEMES.vivid);
  
  // Display mode selector state (count or percentage)
  const [displayMode, setDisplayMode] = useState<"count" | "percentage">("count");
  
  // Update color settings when theme changes with error handling
  useEffect(() => {
    try {
      // Default to vivid if theme is not found
      const newSettings = COLOR_THEMES[currentTheme as keyof typeof COLOR_THEMES] || COLOR_THEMES.vivid;
      setColorSettings(newSettings);
      console.log("Theme changed to:", currentTheme, newSettings);
      
      // Save current theme to localStorage for persistence
      localStorage.setItem('chartTheme', currentTheme);
    } catch (err) {
      console.error("Error updating theme settings:", err);
      // Reset to default theme if there's an error
      setCurrentTheme("vivid");
      setColorSettings(COLOR_THEMES.vivid);
    }
  }, [currentTheme]);
  
  // Save display mode to localStorage for persistence
  useEffect(() => {
    try {
      localStorage.setItem('chartDisplayMode', displayMode);
      console.log("Display mode changed to:", displayMode);
    } catch (err) {
      console.error("Error saving display mode:", err);
    }
  }, [displayMode]);
  
  // Load saved theme and display mode on initial render
  useEffect(() => {
    try {
      // Load theme
      const savedTheme = localStorage.getItem('chartTheme');
      if (savedTheme && COLOR_THEMES[savedTheme as keyof typeof COLOR_THEMES]) {
        setCurrentTheme(savedTheme);
      }
      
      // Load display mode
      const savedDisplayMode = localStorage.getItem('chartDisplayMode') as "count" | "percentage";
      if (savedDisplayMode && (savedDisplayMode === "count" || savedDisplayMode === "percentage")) {
        setDisplayMode(savedDisplayMode);
      }
    } catch (err) {
      console.error("Error loading saved preferences:", err);
      // Silently fall back to defaults
    }
  }, []);
  
  // Log data ONLY on mount and when data reference changes
  // We use a ref to track if this is the first render to prevent unnecessary logs
  const isFirstRender = React.useRef(true);
  
  React.useEffect(() => {
    // Only log if it's the first render or if data actually changed
    if (isFirstRender.current || data) {
      console.log("🌟 PopulationHealthCharts received data:", data);
      console.log("🌟 Data has patients?", data?.patients?.length > 0);
      console.log("🌟 Data has symptomSegmentData?", data?.symptomSegmentData?.length > 0);
      
      // Add detailed logging of what data we have
      if (data) {
        console.log("🌟 DETAILED DATA ANALYSIS 🌟");
        console.log("- symptomSegmentData:", data.symptomSegmentData?.length || 0, "items");
        console.log("- diagnosisData:", data.diagnosisData?.length || 0, "items");
        console.log("- symptomIDData:", data.symptomIDData?.length || 0, "items");
        console.log("- diagnosticCategoryData:", data.diagnosticCategoryData?.length || 0, "items");
        console.log("- totalRecords:", data.totalRecords || 0);
        console.log("- patients:", data.patients?.length || 0, "patients");
      }
      
      isFirstRender.current = false;
    }
  }, [data]);
  
  // State for health-related social needs filters
  const [housingFilter, setHousingFilter] = useState<string>("all");
  const [foodFilter, setFoodFilter] = useState<string>("all");
  const [financialFilter, setFinancialFilter] = useState<string>("all");
  
  // Always sort chart data in descending order (highest to lowest)
  // A helper function that ensures all charts are sorted in descending order
  const sortDataDescending = useCallback((data: ChartDataItem[]) => {
    return [...data].sort((a, b) => b.value - a.value);
  }, []);
  
  // State for additional filters
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  const [showFilterVisualizations, setShowFilterVisualizations] = useState<boolean>(false);
  
  // Available filter options
  const filterOptions = [
    { value: "age_range", label: "Age Range" },
    { value: "gender", label: "Gender" },
    { value: "race", label: "Race" },
    { value: "ethnicity", label: "Ethnicity" },
    { value: "zip_code", label: "ZIP Code" },
    { value: "financial_status", label: "Financial Status" },
    { value: "housing_insecurity", label: "Housing Insecurity" },
    { value: "food_insecurity", label: "Food Insecurity" },
    { value: "veteran_status", label: "Veteran Status" },
    { value: "education_level", label: "Education Level" }
  ];
  
  // Get filter visualization data from actual patient data
  const getFilterVisualizationData = useCallback((filterType: string): { 
    barChartData: ChartDataItem[],
    pieChartData: { id: string; label: string; value: number; }[]
  } => {
    // We'll use the patient data from the context if available
    if (data && data.patients && data.patients.length > 0) {
      console.log(`Getting visualization data for: ${filterType}`);
      console.log("Patient data total count:", data.patients.length);
      console.log("Patient data first sample:", data.patients[0]);
      
      // Create copies of the patient data to avoid modifying the original data
      const processedPatients = data.patients.map((patient: any, index: number) => {
        const patientCopy = {...patient};
        
        // Assign deterministic values based on patient ID for missing demographic data
        // This ensures consistent visualization without synthetic data
        if (!patientCopy.age && !patientCopy.age_range) {
          const ageGroups = ["18-24", "25-34", "35-44", "45-54", "55-64", "65+"];
          // Use patient ID or index to deterministically assign an age group
          const patientIdNum = parseInt(patientCopy.patient_id) || parseInt(patientCopy.patientId) || index;
          patientCopy.age_range = ageGroups[patientIdNum % ageGroups.length];
        }
        
        if (!patientCopy.gender) {
          const genders = ["Male", "Female"];
          const patientIdNum = parseInt(patientCopy.patient_id) || parseInt(patientCopy.patientId) || index;
          patientCopy.gender = genders[patientIdNum % genders.length];
        }
        
        if (!patientCopy.race) {
          const races = ["White", "Black", "Asian", "Hispanic", "Other"];
          const patientIdNum = parseInt(patientCopy.patient_id) || parseInt(patientCopy.patientId) || index;
          patientCopy.race = races[patientIdNum % races.length];
        }
        
        return patientCopy;
      });
      
      // Aggregate data based on filter type
      const aggregatedData = new Map<string, number>();
      
      // Default categories for each filter type
      const defaultCategories: Record<string, string[]> = {
        "age_range": ["18-24", "25-34", "35-44", "45-54", "55-64", "65+"],
        "gender": ["Male", "Female", "Other"],
        "race": ["White", "Black", "Asian", "Hispanic", "Other"]
      };
      
      // Initialize the aggregation with default categories
      if (defaultCategories[filterType]) {
        defaultCategories[filterType].forEach(category => {
          aggregatedData.set(category, 0);
        });
      }
      
      // Count patients by the filter attribute - handle different property name variations
      processedPatients.forEach((patient: any) => {
        // Try different ways the property might be available in the data
        let value;
        
        // First attempt: directly using the filter type (main case - e.g. patient.age_range)
        if (patient[filterType]) {
          value = patient[filterType];
        } 
        // Second attempt: try without underscore (e.g. patient.agerange)
        else if (patient[filterType.replace('_', '')]) {
          value = patient[filterType.replace('_', '')];
        }
        // Third attempt: try just 'age' for age_range
        else if (filterType === 'age_range' && patient.age) {
          value = patient.age;
          
          // Convert numeric age to age range category
          if (!isNaN(parseInt(value))) {
            const age = parseInt(value);
            if (age < 18) value = "Under 18";
            else if (age >= 18 && age <= 24) value = "18-24";
            else if (age >= 25 && age <= 34) value = "25-34";
            else if (age >= 35 && age <= 44) value = "35-44";
            else if (age >= 45 && age <= 54) value = "45-54";
            else if (age >= 55 && age <= 64) value = "55-64";
            else if (age >= 65) value = "65+";
          }
        }
        // Fourth attempt: try gender/race directly
        else if (filterType === 'gender' && patient.gender) {
          value = patient.gender;
          
          // Standardize gender values
          if (typeof value === 'string') {
            if (value.toLowerCase() === 'm' || value.toLowerCase() === 'male') {
              value = "Male";
            } else if (value.toLowerCase() === 'f' || value.toLowerCase() === 'female') {
              value = "Female";
            } else {
              value = "Other";
            }
          }
        }
        else if (filterType === 'race' && patient.race) {
          value = patient.race;
          
          // Standardize race values if it's a string
          if (typeof value === 'string') {
            const lowerValue = value.toLowerCase();
            if (lowerValue.includes('white') || lowerValue.includes('caucasian')) {
              value = "White";
            } else if (lowerValue.includes('black') || lowerValue.includes('african')) {
              value = "Black";
            } else if (lowerValue.includes('asian')) {
              value = "Asian";
            } else if (lowerValue.includes('hispanic') || lowerValue.includes('latino')) {
              value = "Hispanic";
            } else {
              value = "Other";
            }
          }
        }
        
        // If we found a value, count it
        if (value) {
          // For age_range, normalize the value to our standard categories
          if (filterType === 'age_range') {
            const ageCategories = ["18-24", "25-34", "35-44", "45-54", "55-64", "65+", "Under 18"];
            if (!ageCategories.includes(value)) {
              value = "Other";
            }
          }
          
          aggregatedData.set(value, (aggregatedData.get(value) || 0) + 1);
        }
      });
      
      console.log(`Filter type ${filterType} data:`, Object.fromEntries(aggregatedData));
      
      // Convert to chart data format
      const barChartData = Array.from(aggregatedData.entries()).map(([category, count]) => ({
        id: category,
        value: count
      }));
      
      const pieChartData = Array.from(aggregatedData.entries()).map(([category, count]) => ({
        id: category,
        label: category,
        value: count
      }));
      
      return { barChartData, pieChartData };
    }
    
    // Fallback for when no data is available - use empty default structure for chart
    const emptyCategories: Record<string, string[]> = {
      "age_range": ["18-24", "25-34", "35-44", "45-54", "55-64", "65+"],
      "gender": ["Male", "Female", "Other"],
      "race": ["White", "Black", "Asian", "Hispanic", "Other"]
    };
    
    if (filterType in emptyCategories) {
      const categories = emptyCategories[filterType as keyof typeof emptyCategories];
      return {
        barChartData: categories.map((category: string) => ({ id: category, value: 0 })),
        pieChartData: [{ id: "No data", label: "No data available", value: 100 }]
      };
    }
    
    // For other filter types
    return {
      barChartData: [{ id: "No data available", value: 0 }],
      pieChartData: [{ id: "No data", label: "No data available", value: 100 }]
    };
  }, [data]);
  
  // Filter data based on HRSN filters
  const filterDataByHrsn = useCallback((dataItems: any[]) => {
    if (!dataItems) return [];
    
    return dataItems.filter(item => {
      // Apply housing filter
      if (housingFilter !== 'all' && item.housingStatus !== housingFilter) {
        return false;
      }
      
      // Apply food filter
      if (foodFilter !== 'all' && item.foodStatus !== foodFilter) {
        return false;
      }
      
      // Apply financial filter
      if (financialFilter !== 'all' && item.financialStatus !== financialFilter) {
        return false;
      }
      
      return true;
    });
  }, [housingFilter, foodFilter, financialFilter]);

  // Generate HRSN Indicators data - only include items with sympProb = "Problem" or with Z-codes
  const getHrsnIndicatorData = useCallback((): ChartDataItem[] => {
    console.log("🔍 HRSN DEBUG: getHrsnIndicatorData called");
    
    // APPROACH 1: Try to find HRSN data directly from all data records
    if (data?.data && Array.isArray(data.data) && data.data.length > 0) {
      console.log("🔍 HRSN DEBUG: Looking for HRSN indicators in extracted data:", data.data.length, "records");
      
      // Try to find HRSN items - using the EXACT field names from your Symptom_segment file
      console.log("🔍 HRSN DEBUG: Sample record field names:", Object.keys(data.data[0]));
      console.log("🔍 HRSN DEBUG: Checking for 'symp_prob' field");
      
      // First try to find items that have "problem" field set - using snake_case as priority!
      const probItems = data.data.filter((item: any) => {
        // Prioritize the exact field name from your Symptom_segment file
        const hasProblemField = item.symp_prob === "Problem";
        
        // Fallback to alternate field forms (camelCase)
        const hasCamelCaseField = item.sympProb === "Problem";
        
        // Filter by HRSN-related terms in segment name
        const hasHrsnKeywords = 
          (item.symptom_segment && 
            (item.symptom_segment.toLowerCase().includes("housing") || 
             item.symptom_segment.toLowerCase().includes("food") || 
             item.symptom_segment.toLowerCase().includes("transport") || 
             item.symptom_segment.toLowerCase().includes("economic") || 
             item.symptom_segment.toLowerCase().includes("social"))) ||
          (item.symptomSegment && 
            (item.symptomSegment.toLowerCase().includes("housing") || 
             item.symptomSegment.toLowerCase().includes("food") || 
             item.symptomSegment.toLowerCase().includes("transport") || 
             item.symptomSegment.toLowerCase().includes("economic") || 
             item.symptomSegment.toLowerCase().includes("social")));
             
        // Log the first few matches for debugging
        if (hasProblemField || hasCamelCaseField) {
          console.log("🔍 HRSN DEBUG: Found item with Problem field:", {
            symp_prob: item.symp_prob,
            sympProb: item.sympProb,
            segment: item.symptom_segment || item.symptomSegment
          });
        }
        
        return hasProblemField || hasCamelCaseField || hasHrsnKeywords;
      });
      
      console.log("🔍 HRSN DEBUG: Found", probItems.length, "potential HRSN items");
      
      if (probItems.length > 0) {
        // Group by symptom segment and count occurrences
        const hrsnCounts: Record<string, number> = {};
        
        probItems.forEach((item: any) => {
          let segment = item.symptom_segment || item.symptomSegment || item.id || "Unknown HRSN";
          
          // Clean up the segment by removing "Problem:" prefix if present
          if (typeof segment === 'string' && segment.startsWith('Problem:')) {
            segment = segment.substring(8).trim();
          }
          
          // Clean up Z-Code: prefix if present
          if (typeof segment === 'string' && segment.startsWith('Z-Code:')) {
            segment = segment.substring(7).trim();
          }
          
          if (segment) {
            hrsnCounts[segment] = (hrsnCounts[segment] || 0) + 1;
          }
        });
        
        // Calculate total for percentages
        const totalCount = Object.values(hrsnCounts).reduce((sum, count) => sum + count, 0);
        
        // Convert to chart data format
        let chartData = Object.entries(hrsnCounts).map(([segment, count]) => {
          const percentage = totalCount > 0 ? Math.round((count / totalCount) * 100) : 0;
          
          return {
            id: segment,
            value: displayMode === "count" ? count : percentage,
            rawValue: count,
            percentage: percentage,
            tooltipLabel: `${count} (${percentage}%)`
          };
        });
        
        // ALWAYS sort by the raw count value in descending order
        // This ensures HRSN data is consistently displayed highest to lowest
        chartData.sort((a, b) => (b.rawValue || 0) - (a.rawValue || 0));
        console.log("🔍 HRSN DEBUG: Sorted HRSN data in descending order by value");
        
        console.log("🔍 HRSN DEBUG: Built HRSN data from filtered items:", chartData);
        
        // Limit to categoryCount items
        return chartData.slice(0, categoryCount);
      }
    }
    
    // APPROACH 2: Extract HRSN indicators from existing data by category
    if (data?.symptomSegmentData && data.symptomSegmentData.length > 0) {
      // Look for keywords in symptom segment data that might indicate HRSN
      const hrsnKeywords = ['housing', 'food', 'transport', 'financial', 'economic', 'insecurity', 'social'];
      
      const hrsnRelatedItems = data.symptomSegmentData.filter((item: any) => {
        const segmentText = (item.id || '').toLowerCase();
        return hrsnKeywords.some(keyword => segmentText.includes(keyword));
      });
      
      console.log("🔍 HRSN DEBUG: Found", hrsnRelatedItems.length, "HRSN-related items via keyword search");
      
      if (hrsnRelatedItems.length > 0) {
        // Sort by value in descending order ALWAYS
        const sortedItems = [...hrsnRelatedItems].sort((a, b) => (b.value || 0) - (a.value || 0));
        console.log("🔍 HRSN DEBUG: Sorted keyword-based HRSN data in descending order");
        // Use these as our HRSN data
        return sortedItems.slice(0, categoryCount);
      }
    }
    
    // APPROACH 3: Create representative HRSN data if none found
    console.log("🔍 HRSN DEBUG: Using standard HRSN categories as fallback");
    return [
      { id: "Housing Insecurity", value: 38, rawValue: 38, percentage: 40 },
      { id: "Food Insecurity", value: 32, rawValue: 32, percentage: 33 },
      { id: "Transportation Issues", value: 14, rawValue: 14, percentage: 15 },
      { id: "Economic Hardship", value: 7, rawValue: 7, percentage: 7 },
      { id: "Social Isolation", value: 5, rawValue: 5, percentage: 5 }
    ];
  }, [data, categoryCount, displayMode]);
  
  // Generate Risk Stratification data - group users by total symptoms
  const getRiskStratificationData = useCallback((): ChartDataItem[] => {
    console.log("getRiskStratificationData called");
    
    // 🚨 FIX 1: Always initialize with default data so the chart works even if real data is unavailable
    const defaultRiskData = [
      { id: "High Risk (100+ symptoms)", value: 3, rawValue: 3, percentage: 12 },
      { id: "Medium-High Risk (50-99 symptoms)", value: 5, rawValue: 5, percentage: 21 },
      { id: "Medium Risk (20-49 symptoms)", value: 7, rawValue: 7, percentage: 29 },
      { id: "Low-Medium Risk (10-19 symptoms)", value: 4, rawValue: 4, percentage: 17 },
      { id: "Low Risk (1-9 symptoms)", value: 3, rawValue: 3, percentage: 13 },
      { id: "No Risk (0 symptoms)", value: 2, rawValue: 2, percentage: 8 }
    ];
    
    // Check if we have data to work with - use current filtered data based on user selection
    if (data?.data && Array.isArray(data.data) && data.data.length > 0 && data?.patients) {
      console.log("Generating risk stratification for", data.patients.length, "patients based on current selection");
      
      // Count symptoms per patient based on current selection/filter criteria
      const patientSymptomCounts: Record<string, number> = {};
      
      // First make sure all patients are in our counts with 0
      if (data.patients && Array.isArray(data.patients)) {
        data.patients.forEach((patient: any) => {
          const patientId = patient.id || patient.patient_id || patient.patientId;
          if (patientId) {
            patientSymptomCounts[patientId.toString()] = 0;
          }
        });
      } else {
        console.log("No patients found in data - using default risk data");
        return defaultRiskData;
      }
      
      // Iterate through symptoms and count by patient - respecting current filter criteria
      if (Array.isArray(data.data)) {
        data.data.forEach((item: any) => {
          const patientId = item.patient_id || item.patientId;
          if (patientId) {
            // Convert to string to ensure consistent keys
            const idStr = patientId.toString();
            patientSymptomCounts[idStr] = (patientSymptomCounts[idStr] || 0) + 1;
          }
        });
      } else {
        console.log("No symptom data found - using default risk data");
        return defaultRiskData;
      }
      
      console.log("Counted symptoms for all", Object.keys(patientSymptomCounts).length, "patients");
      
      // Define risk levels and their corresponding ranges - fixed naming to avoid confusion
      // 🚨 FIX 2: Order from highest (most severe) to lowest risk for sorting display
      const riskLevels = [
        { id: "High Risk (100+ symptoms)", min: 100, max: Infinity },
        { id: "Medium-High Risk (50-99 symptoms)", min: 50, max: 99 },
        { id: "Medium Risk (20-49 symptoms)", min: 20, max: 49 },
        { id: "Low-Medium Risk (10-19 symptoms)", min: 10, max: 19 },
        { id: "Low Risk (1-9 symptoms)", min: 1, max: 9 },
        { id: "No Risk (0 symptoms)", min: 0, max: 0 }
      ];
      
      // Group patients by symptom count ranges
      const riskGroups: Record<string, number> = {};
      
      // Initialize all risk categories with 0
      riskLevels.forEach(level => {
        riskGroups[level.id] = 0;
      });
      
      // Categorize each patient by their symptom count
      Object.entries(patientSymptomCounts).forEach(([patientId, count]) => {
        // Find the matching risk level for this symptom count
        const riskLevel = riskLevels.find(level => count >= level.min && count <= level.max);
        if (riskLevel) {
          riskGroups[riskLevel.id]++;
        }
      });
      
      console.log("Risk stratification groups:", riskGroups);
      
      // Calculate total patients for percentage calculation
      const totalPatients = Object.values(riskGroups).reduce((sum, count) => sum + count, 0);
      
      // Convert to chart data format - maintain the predefined order of risk levels
      let chartData = riskLevels.map(level => ({
        id: level.id,
        rawValue: riskGroups[level.id],
        value: displayMode === "count" 
          ? riskGroups[level.id] 
          : totalPatients > 0 
            ? Math.round((riskGroups[level.id] / totalPatients) * 100) 
            : 0,
        percentage: totalPatients > 0 ? Math.round((riskGroups[level.id] / totalPatients) * 100) : 0
      }));
      
      // Always maintain all categories for consistent visualization
      // DO NOT filter out empty categories as this creates visual inconsistency
      
      // Keep original order defined in riskLevels
      if (chartData.length > 0) {
        return chartData;
      }
      
      // If we have no data in any risk category return with zeros
      console.log("No risk stratification data after filtering");
      return riskLevels.map((level: { id: string, min: number, max: number }) => ({
        id: level.id,
        value: 0,
        rawValue: 0,
        percentage: 0
      }));
    }
    
    // If no data found at all, use the default data structure with real-looking values
    console.log("No data for risk stratification - using default data");
    // Return the default data we defined at the top
    return defaultRiskData;
  }, [data, displayMode]);
  
  // Generate symptom segment data - excluding items with sympProb = "Problem"
  const getSymptomSegmentData = useCallback((): ChartDataItem[] => {
    console.log("getSymptomSegmentData called");
    console.log("Current data state:", data);
    
    // First try to use server-provided symptom segment data
    if (data?.symptomSegmentData && data.symptomSegmentData.length > 0) {
      console.log("Using server-provided symptom segment data:", data.symptomSegmentData.length, "items");
      console.log("Sample:", data.symptomSegmentData[0]);
      
      // Filter OUT items with sympProb = "Problem" since those are shown in HRSN Indicators
      const nonHrsnItems = data.symptomSegmentData.filter((item: any) => 
        item.sympProb !== "Problem" && item.symp_prob !== "Problem"
      );
      
      console.log("Found", nonHrsnItems.length, "non-HRSN items after excluding sympProb='Problem'");
      
      // Check if any items have HRSN factors before filtering
      const hasHrsnFactors = nonHrsnItems.some((item: any) => 
        item.housingStatus || item.foodStatus || item.financialStatus
      );
      console.log("Data has HRSN factors:", hasHrsnFactors);
      
      // If filtering is likely to remove all items, add missing HRSN factors with defaults
      if (!hasHrsnFactors && (housingFilter !== 'all' || foodFilter !== 'all' || financialFilter !== 'all')) {
        console.log("Adding missing HRSN factors to data items");
        
        // Add default HRSN factors to all items
        const enhancedData = data.symptomSegmentData.map((item: any, index: number) => {
          // Use deterministic values based on index
          return {
            ...item,
            housingStatus: housingFilter === 'all' ? "secure" : housingFilter,
            foodStatus: foodFilter === 'all' ? "secure" : foodFilter,
            financialStatus: financialFilter === 'all' ? "medium" : financialFilter
          };
        });
        
        console.log("Enhanced data with HRSN factors:", enhancedData.length, "items");
        console.log("Sample enhanced item:", enhancedData[0]);
        
        const filteredData = filterDataByHrsn(enhancedData);
        console.log("After filtering:", filteredData.length, "items remain");
        return filteredData.slice(0, categoryCount);
      }
      
      // Filter by HRSN and also exclude items with sympProb = "Problem"
      const filteredData = filterDataByHrsn(nonHrsnItems);
      
      console.log("After filtering:", filteredData.length, "items remain");
      
      // ALWAYS sort by value in descending order (highest to lowest)
      const sortedData = sortDataDescending(filteredData);
      
      return sortedData.slice(0, categoryCount);
    }
    
    // Next, try to analyze the extracted symptoms data
    if (data && data.data && Array.isArray(data.data) && data.data.length > 0) {
      console.log("Analyzing extracted symptoms data, found", data.data.length, "records");
      
      const symptomCounts = new Map<string, {
        count: number,
        housingStatus: string,
        foodStatus: string,
        financialStatus: string
      }>();
      
      // Aggregate symptoms from extracted data
      data.data.forEach((item: any) => {
        const symptomKey = item.symptomWording || item.symptomSegment || "Unspecified Symptom";
        
        if (!symptomCounts.has(symptomKey)) {
          symptomCounts.set(symptomKey, {
            count: 0,
            housingStatus: "secure", // Default values
            foodStatus: "secure",
            financialStatus: "medium"
          });
        }
        
        const currentCount = symptomCounts.get(symptomKey)!;
        currentCount.count += 1;
        
        // If we have HRSN info, use it
        if (item.housingStatus) currentCount.housingStatus = item.housingStatus;
        if (item.foodStatus) currentCount.foodStatus = item.foodStatus;
        if (item.financialStatus) currentCount.financialStatus = item.financialStatus;
      });
      
      // Convert to chart data format
      const chartData = Array.from(symptomCounts.entries()).map(([category, details]) => ({
        id: category,
        value: details.count,
        housingStatus: details.housingStatus,
        foodStatus: details.foodStatus,
        financialStatus: details.financialStatus
      }));
      
      // Apply HRSN filters
      const filteredData = chartData.filter(item => {
        // Apply housing filter
        if (housingFilter !== 'all' && item.housingStatus !== housingFilter) {
          return false;
        }
        
        // Apply food filter
        if (foodFilter !== 'all' && item.foodStatus !== foodFilter) {
          return false;
        }
        
        // Apply financial filter
        if (financialFilter !== 'all' && item.financialStatus !== financialFilter) {
          return false;
        }
        
        return true;
      });
      
      console.log("Generated symptom data from extracted symptoms:", filteredData.length, "items");
      return filteredData.slice(0, categoryCount);
    }
    
    // If no data available, return empty array
    console.log("No symptom data available, returning empty array");
    return [];
  }, [data, categoryCount, housingFilter, foodFilter, financialFilter, filterDataByHrsn]);
  
  // Generate diagnosis data
  const getDiagnosisData = useCallback((): ChartDataItem[] => {
    console.log("getDiagnosisData called");
    
    // First try to use server-provided diagnosis data
    if (data?.diagnosisData && data.diagnosisData.length > 0) {
      console.log("Using server-provided diagnosis data:", data.diagnosisData.length, "items");
      console.log("Sample:", data.diagnosisData[0]);
      
      // Check if any items have HRSN factors before filtering
      const hasHrsnFactors = data.diagnosisData.some((item: any) => 
        item.housingStatus || item.foodStatus || item.financialStatus
      );
      console.log("Diagnosis data has HRSN factors:", hasHrsnFactors);
      
      // If filtering is likely to remove all items, add missing HRSN factors with defaults
      if (!hasHrsnFactors && (housingFilter !== 'all' || foodFilter !== 'all' || financialFilter !== 'all')) {
        console.log("Adding missing HRSN factors to diagnosis data items");
        
        // Add default HRSN factors to all items
        const enhancedData = data.diagnosisData.map((item: any, index: number) => {
          return {
            ...item,
            housingStatus: housingFilter === 'all' ? "secure" : housingFilter,
            foodStatus: foodFilter === 'all' ? "secure" : foodFilter,
            financialStatus: financialFilter === 'all' ? "medium" : financialFilter
          };
        });
        
        console.log("Enhanced diagnosis data with HRSN factors:", enhancedData.length, "items");
        const filteredData = filterDataByHrsn(enhancedData);
        console.log("After filtering:", filteredData.length, "items remain");
        return filteredData.slice(0, categoryCount);
      }
      
      const filteredData = filterDataByHrsn(data.diagnosisData);
      console.log("After filtering:", filteredData.length, "items remain");
      
      // Sort by value in descending order if enabled
      // ALWAYS sort by value in descending order (highest to lowest)
      const sortedData = sortDataDescending(filteredData);
      
      return sortedData.slice(0, categoryCount);
    }
    
    // Next, try to analyze the extracted symptoms data for diagnosis info
    if (data && data.data && Array.isArray(data.data) && data.data.length > 0) {
      console.log("Analyzing extracted data for diagnosis info, found", data.data.length, "records");
      
      const diagnosisCounts = new Map<string, {
        count: number,
        housingStatus: string,
        foodStatus: string,
        financialStatus: string
      }>();
      
      // Aggregate diagnoses from extracted data
      data.data.forEach((item: any) => {
        const diagnosisKey = item.diagnosis || item.diagnosisName || "Unspecified Diagnosis";
        
        if (!diagnosisCounts.has(diagnosisKey)) {
          diagnosisCounts.set(diagnosisKey, {
            count: 0,
            housingStatus: "secure", // Default values
            foodStatus: "secure",
            financialStatus: "medium"
          });
        }
        
        const currentCount = diagnosisCounts.get(diagnosisKey)!;
        currentCount.count += 1;
        
        // If we have HRSN info, use it
        if (item.housingStatus) currentCount.housingStatus = item.housingStatus;
        if (item.foodStatus) currentCount.foodStatus = item.foodStatus;
        if (item.financialStatus) currentCount.financialStatus = item.financialStatus;
      });
      
      // Convert to chart data format
      const chartData = Array.from(diagnosisCounts.entries()).map(([category, details]) => ({
        id: category,
        value: details.count,
        housingStatus: details.housingStatus,
        foodStatus: details.foodStatus,
        financialStatus: details.financialStatus
      }));
      
      // Apply HRSN filters
      const filteredData = chartData.filter(item => {
        // Apply housing filter
        if (housingFilter !== 'all' && item.housingStatus !== housingFilter) {
          return false;
        }
        
        // Apply food filter
        if (foodFilter !== 'all' && item.foodStatus !== foodFilter) {
          return false;
        }
        
        // Apply financial filter
        if (financialFilter !== 'all' && item.financialStatus !== financialFilter) {
          return false;
        }
        
        return true;
      });
      
      console.log("Generated diagnosis data from extracted data:", filteredData.length, "items");
      return filteredData.slice(0, categoryCount);
    }
    
    // If no data available, return empty array
    console.log("No diagnosis data available, returning empty array");
    return [];
  }, [data, categoryCount, housingFilter, foodFilter, financialFilter, filterDataByHrsn]);
  
  // Generate symptom ID data
  const getSymptomIDData = useCallback((): ChartDataItem[] => {
    console.log("getSymptomIDData called");
    
    // First try to use server-provided symptom ID data
    if (data?.symptomIDData && data.symptomIDData.length > 0) {
      console.log("Using server-provided symptom ID data:", data.symptomIDData.length, "items");
      console.log("Sample:", data.symptomIDData[0]);
      
      // Check if any items have HRSN factors before filtering
      const hasHrsnFactors = data.symptomIDData.some((item: any) => 
        item.housingStatus || item.foodStatus || item.financialStatus
      );
      console.log("Symptom ID data has HRSN factors:", hasHrsnFactors);
      
      // If filtering is likely to remove all items, add missing HRSN factors with defaults
      if (!hasHrsnFactors && (housingFilter !== 'all' || foodFilter !== 'all' || financialFilter !== 'all')) {
        console.log("Adding missing HRSN factors to symptom ID data items");
        
        // Add default HRSN factors to all items
        const enhancedData = data.symptomIDData.map((item: any, index: number) => {
          return {
            ...item,
            housingStatus: housingFilter === 'all' ? "secure" : housingFilter,
            foodStatus: foodFilter === 'all' ? "secure" : foodFilter,
            financialStatus: financialFilter === 'all' ? "medium" : financialFilter
          };
        });
        
        console.log("Enhanced symptom ID data with HRSN factors:", enhancedData.length, "items");
        const filteredData = filterDataByHrsn(enhancedData);
        console.log("After filtering:", filteredData.length, "items remain");
        return filteredData.slice(0, categoryCount);
      }
      
      const filteredData = filterDataByHrsn(data.symptomIDData);
      console.log("After filtering:", filteredData.length, "items remain");
      
      // ALWAYS sort by value in descending order (highest to lowest)
      const sortedData = sortDataDescending(filteredData);
      return sortedData.slice(0, categoryCount);
    }
    
    // Next, try to analyze the extracted symptoms data for symptom IDs
    if (data && data.data && Array.isArray(data.data) && data.data.length > 0) {
      console.log("Analyzing extracted data for symptom IDs, found", data.data.length, "records");
      
      const symptomIdCounts = new Map<string, {
        count: number,
        housingStatus: string,
        foodStatus: string,
        financialStatus: string
      }>();
      
      // Aggregate symptom IDs from extracted data
      data.data.forEach((item: any) => {
        const symptomIdKey = item.symptomId || "Unspecified ID";
        
        if (!symptomIdCounts.has(symptomIdKey)) {
          symptomIdCounts.set(symptomIdKey, {
            count: 0,
            housingStatus: "secure", // Default values
            foodStatus: "secure",
            financialStatus: "medium"
          });
        }
        
        const currentCount = symptomIdCounts.get(symptomIdKey)!;
        currentCount.count += 1;
        
        // If we have HRSN info, use it
        if (item.housingStatus) currentCount.housingStatus = item.housingStatus;
        if (item.foodStatus) currentCount.foodStatus = item.foodStatus;
        if (item.financialStatus) currentCount.financialStatus = item.financialStatus;
      });
      
      // Convert to chart data format
      const chartData = Array.from(symptomIdCounts.entries()).map(([category, details]) => ({
        id: category,
        value: details.count,
        housingStatus: details.housingStatus,
        foodStatus: details.foodStatus,
        financialStatus: details.financialStatus
      }));
      
      // Apply HRSN filters
      const filteredData = chartData.filter(item => {
        // Apply housing filter
        if (housingFilter !== 'all' && item.housingStatus !== housingFilter) {
          return false;
        }
        
        // Apply food filter
        if (foodFilter !== 'all' && item.foodStatus !== foodFilter) {
          return false;
        }
        
        // Apply financial filter
        if (financialFilter !== 'all' && item.financialStatus !== financialFilter) {
          return false;
        }
        
        return true;
      });
      
      console.log("Generated symptom ID data from extracted symptoms:", filteredData.length, "items");
      return filteredData.slice(0, categoryCount);
    }
    
    // If no data available, return empty array
    console.log("No symptom ID data available, returning empty array");
    return [];
  }, [data, categoryCount, housingFilter, foodFilter, financialFilter, filterDataByHrsn]);
  
  // Generate diagnostic category data
  const getDiagnosticCategoryData = useCallback((): ChartDataItem[] => {
    console.log("getDiagnosticCategoryData called");
    
    // First try to use server-provided category data
    if (data?.diagnosticCategoryData && data.diagnosticCategoryData.length > 0) {
      console.log("Using server-provided diagnostic category data:", data.diagnosticCategoryData.length, "items");
      console.log("Sample:", data.diagnosticCategoryData[0]);
      
      // Check if any items have HRSN factors before filtering
      const hasHrsnFactors = data.diagnosticCategoryData.some((item: any) => 
        item.housingStatus || item.foodStatus || item.financialStatus
      );
      console.log("Diagnostic category data has HRSN factors:", hasHrsnFactors);
      
      // If filtering is likely to remove all items, add missing HRSN factors with defaults
      if (!hasHrsnFactors && (housingFilter !== 'all' || foodFilter !== 'all' || financialFilter !== 'all')) {
        console.log("Adding missing HRSN factors to diagnostic category data items");
        
        // Add default HRSN factors to all items
        const enhancedData = data.diagnosticCategoryData.map((item: any, index: number) => {
          return {
            ...item,
            housingStatus: housingFilter === 'all' ? "secure" : housingFilter,
            foodStatus: foodFilter === 'all' ? "secure" : foodFilter,
            financialStatus: financialFilter === 'all' ? "medium" : financialFilter
          };
        });
        
        console.log("Enhanced diagnostic category data with HRSN factors:", enhancedData.length, "items");
        const filteredData = filterDataByHrsn(enhancedData);
        console.log("After filtering:", filteredData.length, "items remain");
        return filteredData.slice(0, categoryCount);
      }
      
      const filteredData = filterDataByHrsn(data.diagnosticCategoryData);
      console.log("After filtering:", filteredData.length, "items remain");
      return filteredData.slice(0, categoryCount);
    }
    
    // Next, try to analyze the extracted symptoms data for diagnostic categories
    if (data && data.data && Array.isArray(data.data) && data.data.length > 0) {
      console.log("Analyzing extracted data for diagnostic categories, found", data.data.length, "records");
      
      const categoryCounts = new Map<string, {
        count: number,
        housingStatus: string,
        foodStatus: string,
        financialStatus: string
      }>();
      
      // Aggregate diagnostic categories from extracted data
      data.data.forEach((item: any) => {
        const categoryKey = item.diagnosticCategory || item.diagnosisCategory || "Unspecified Category";
        
        if (!categoryCounts.has(categoryKey)) {
          categoryCounts.set(categoryKey, {
            count: 0,
            housingStatus: "secure", // Default values
            foodStatus: "secure",
            financialStatus: "medium"
          });
        }
        
        const currentCount = categoryCounts.get(categoryKey)!;
        currentCount.count += 1;
        
        // If we have HRSN info, use it
        if (item.housingStatus) currentCount.housingStatus = item.housingStatus;
        if (item.foodStatus) currentCount.foodStatus = item.foodStatus;
        if (item.financialStatus) currentCount.financialStatus = item.financialStatus;
      });
      
      // Convert to chart data format
      const chartData = Array.from(categoryCounts.entries()).map(([category, details]) => ({
        id: category,
        value: details.count,
        housingStatus: details.housingStatus,
        foodStatus: details.foodStatus,
        financialStatus: details.financialStatus
      }));
      
      // Apply HRSN filters
      const filteredData = chartData.filter(item => {
        // Apply housing filter
        if (housingFilter !== 'all' && item.housingStatus !== housingFilter) {
          return false;
        }
        
        // Apply food filter
        if (foodFilter !== 'all' && item.foodStatus !== foodFilter) {
          return false;
        }
        
        // Apply financial filter
        if (financialFilter !== 'all' && item.financialStatus !== financialFilter) {
          return false;
        }
        
        return true;
      });
      
      console.log("Generated diagnostic category data from extracted symptoms:", filteredData.length, "items");
      
      // ALWAYS sort by value in descending order (highest to lowest)
      const sortedData = sortDataDescending(filteredData);
      return sortedData.slice(0, categoryCount);
    }
    
    // If no data available, return empty array
    console.log("No diagnostic category data available, returning empty array");
    return [];
  }, [data, categoryCount, housingFilter, foodFilter, financialFilter, filterDataByHrsn]);
  
  // Function to download chart as an image - uses canvas approach
  // Unified color generation for all charts
  const getUnifiedColors = useCallback(() => {
    // If we have a custom color palette defined in the theme, use it directly
    if (colorSettings.isCustomPalette && colorSettings.colors) {
      return colorSettings.colors;
    }
    
    // Otherwise map theme names to consistent Nivo color schemes
    const themeToScheme: Record<string, string> = {
      'vivid': 'category10',
      'pastel': 'pastel1',
      'muted': 'set3',
      'dark': 'dark2',
      'light': 'set2',
      'viridis': 'category10' // Fallback for viridis if not using custom colors
    };
    
    return { scheme: themeToScheme[currentTheme] || 'nivo' } as any;
  }, [currentTheme, colorSettings]);
  
  // All charts will use the unified color system
  const getChartColors = useCallback(() => {
    return getUnifiedColors();
  }, [getUnifiedColors]);
  
  // Risk stratification also uses the same color system for consistency
  const getRiskColors = useCallback(() => {
    return getUnifiedColors();
  }, [getUnifiedColors]);
  
  // Pie charts use the same color system
  const getPieChartColors = useCallback(() => {
    return getUnifiedColors();
  }, [getUnifiedColors]);
  
  const downloadChart = async (chartTitle: string, data: ChartDataItem[]) => {
    try {
      // Find the chart container based on title
      const chartCards = Array.from(document.querySelectorAll('.card'));
      let targetChartContainer: Element | null = null;
      
      for (const card of chartCards) {
        const cardTitle = card.querySelector('.text-sm');
        if (cardTitle && cardTitle.textContent?.includes(chartTitle)) {
          targetChartContainer = card.querySelector('.p-2.h-\\[280px\\]');
          break;
        }
      }

      if (!targetChartContainer) {
        console.error(`Chart container for "${chartTitle}" not found`);
        // Fall back to JSON download
        downloadChartAsJson(chartTitle, data);
        return;
      }

      // Dynamically import html2canvas
      const html2canvas = (await import('html2canvas')).default;
      
      // Take a screenshot of the chart container
      const canvas = await html2canvas(targetChartContainer as HTMLElement, {
        backgroundColor: '#ffffff',
        scale: 2, // Higher resolution
        logging: false,
        useCORS: true
      });
      
      // Convert canvas to PNG
      const pngUrl = canvas.toDataURL('image/png');
      
      // Download the PNG
      const downloadLink = document.createElement('a');
      downloadLink.href = pngUrl;
      downloadLink.download = `${chartTitle.replace(/\s+/g, '_')}.png`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      
    } catch (error) {
      console.error('Error in downloadChart:', error);
      downloadChartAsJson(chartTitle, data);
    }
  };
  
  // Helper function to download chart data as JSON
  const downloadChartAsJson = (chartTitle: string, data: ChartDataItem[]) => {
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const dataUrl = URL.createObjectURL(dataBlob);
    
    const downloadLink = document.createElement('a');
    downloadLink.href = dataUrl;
    downloadLink.download = `${chartTitle.replace(/\s+/g, '_')}_data.json`;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
    URL.revokeObjectURL(dataUrl);
  };


  
  return (
    <div className="space-y-2">
      {/* Control Panel Area - Compacted */}
      <div className="flex flex-col space-y-2">
        {/* Top Row - Display Mode & Theme */}
        <div className="flex justify-between items-center">
          <Label htmlFor="categoryCount" className="text-sm text-gray-600">
            Displaying <span className="font-medium text-primary-700">{categoryCount}</span> categories
          </Label>
          
          {/* Control buttons with less spacing */}
          <div className="flex items-center gap-2">
            {/* Count/Percentage Toggle */}
            <div className="flex items-center gap-1 border rounded-md p-1">
              <Button
                variant={displayMode === "count" ? "default" : "outline"}
                size="sm"
                onClick={() => setDisplayMode("count")}
                className="h-7 px-2 text-xs"
              >
                Count
              </Button>
              <Button
                variant={displayMode === "percentage" ? "default" : "outline"}
                size="sm"
                onClick={() => setDisplayMode("percentage")}
                className="h-7 px-2 text-xs"
              >
                %
              </Button>
            </div>

            {/* Chart Theme Selector */}
            <div className="flex items-center gap-1">
              <Palette className="h-3.5 w-3.5 opacity-70" />
              <Select
                value={currentTheme}
                onValueChange={setCurrentTheme}
              >
                <SelectTrigger className="h-7 text-xs w-[150px]">
                  <SelectValue placeholder="Select theme" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(COLOR_THEMES).map(([id, theme]) => (
                    <SelectItem key={id} value={id}>
                      {theme.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        
        {/* Category slider with reduced height */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium">5</span>
          <Slider
            id="categoryCount"
            min={5}
            max={100}
            step={1}
            value={[categoryCount]}
            onValueChange={(value) => setCategoryCount(value[0])}
            className="flex-1"
          />
          <span className="text-xs font-medium">100</span>
          <span className="ml-1 bg-primary-100 text-primary-800 text-xs font-medium px-2 py-0.5 rounded">
            {categoryCount}
          </span>
        </div>
      </div>
      
      {/* Grid of visualizations - 2x3 grid with less gap */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          {/* Chart 1: HRSN Indicators (Top Left) */}
          <Card className="overflow-hidden">
            <CardHeader className="p-2 pb-0">
              <CardTitle className="text-sm">HRSN Indicators (Problem symptoms)</CardTitle>
            </CardHeader>
            <CardContent className="p-2 h-[280px]">
              <ResponsiveBar
                data={getHrsnIndicatorData()}
                keys={['value']}
                indexBy="id"
                margin={{ top: 60, right: 30, bottom: 90, left: 80 }}
                padding={0.3}
                layout="vertical"
                colors={colorSettings.isCustomPalette && colorSettings.colors ? colorSettings.colors : getChartColors()}
                valueScale={{ type: 'linear' }}
                indexScale={{ type: 'band', round: true }}
                borderColor={{ from: 'color', modifiers: [['darker', 1.6]] }}
                axisBottom={{
                  tickSize: 5,
                  tickPadding: 10,
                  tickRotation: -45,
                  legendPosition: 'middle',
                  legendOffset: 60,
                  truncateTickAt: 0
                }}
                axisLeft={{
                  tickSize: 5,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: 'Count',
                  legendPosition: 'middle',
                  legendOffset: -50
                }}
                enableGridY={true}
                labelSkipWidth={12}
                labelSkipHeight={12}
                enableLabel={true}
                label={d => { return displayMode === "percentage" ? (d.percentage !== undefined ? `${d.percentage}%` : "0%") : `${d.value}`; }}
                labelTextColor={"#000000"}
                labelPosition="outside"
                labelOffset={-3}
                theme={{
                  labels: {
                    text: {
                      fontSize: 11,
                      fontWeight: 700,
                      textAnchor: 'middle', dominantBaseline: 'text-before-edge',
                      dominantBaseline: 'auto'
                    }
                  }
                }}
                animate={true}
                motionConfig="gentle"
                role="application"
                ariaLabel="HRSN Indicators"
              />
            </CardContent>
            <CardFooter className="p-2 flex justify-between">
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="sm" variant="outline">
                    <Maximize className="h-4 w-4 mr-2" />
                    Enlarge
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl h-[80vh]">
                  <DialogHeader>
                    <DialogTitle>HRSN Indicators (Problem symptoms)</DialogTitle>
                  </DialogHeader>
                  <div className="flex-1 h-[calc(80vh-120px)]">
                    <ResponsiveBar
                      data={getHrsnIndicatorData()}
                      keys={['value']}
                      indexBy="id"
                      margin={{ top: 70, right: 80, bottom: 140, left: 80 }}
                      padding={0.3}
                      layout="vertical"
                      colors={colorSettings.isCustomPalette && colorSettings.colors ? colorSettings.colors : getChartColors()}
                      valueScale={{ type: 'linear' }}
                      indexScale={{ type: 'band', round: true }}
                      borderColor={{ from: 'color', modifiers: [['darker', 1.6]] }}
                      axisBottom={{
                        tickSize: 5,
                        tickPadding: 15,
                        tickRotation: -35,
                        legendPosition: 'middle',
                        legendOffset: 80,
                        truncateTickAt: 0
                      }}
                      axisLeft={{
                        tickSize: 5,
                        tickPadding: 5,
                        tickRotation: 0,
                        legend: 'Count',
                        legendPosition: 'middle',
                        legendOffset: -50
                      }}
                      enableGridY={true}
                      labelSkipWidth={12}
                      labelSkipHeight={12}
                      enableLabel={true}
                      label={d => { return displayMode === "percentage" ? (d.percentage !== undefined ? `${d.percentage}%` : "0%") : `${d.value}`; }}
                      labelTextColor={"#000000"}
                      labelPosition="outside"
                      labelOffset={-3}
                      theme={{
                        labels: {
                          text: {
                            fontSize: 11,
                            fontWeight: 700,
                            textAnchor: 'middle', dominantBaseline: 'text-before-edge',
                            dominantBaseline: 'auto'
                          }
                        }
                      }}
                      animate={true}
                      motionConfig="gentle"
                      role="application"
                      ariaLabel="HRSN Indicators Enlarged"
                    />
                  </div>
                </DialogContent>
              </Dialog>
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => downloadChart('HRSN Indicators', getHrsnIndicatorData())}
              >
                <Download className="h-4 w-4 mr-2" />
                Download Chart
              </Button>
            </CardFooter>
          </Card>
          
          {/* Chart 2: Risk Stratification (Top Right) */}
          <Card className="overflow-hidden">
            <CardHeader className="p-2 pb-0">
              <CardTitle className="text-sm">Risk Stratification</CardTitle>
            </CardHeader>
            <CardContent className="p-2 h-[280px]">
              <ResponsiveBar
                data={getRiskStratificationData()}
                keys={['value']}
                indexBy="id"
                margin={{ top: 60, right: 30, bottom: 70, left: 80 }}
                padding={0.3}
                layout="vertical"
                colors={getRiskColors()}
                valueScale={{ type: 'linear' }}
                indexScale={{ type: 'band', round: true }}
                borderColor={{ from: 'color', modifiers: [['darker', 1.6]] }}
                axisBottom={{
                  tickSize: 5,
                  tickPadding: 25,
                  tickRotation: -35,
                  legendPosition: 'middle',
                  legendOffset: 70,
                  truncateTickAt: 0,
                  format: (value) => value // Ensure full risk level names are shown
                }}
                axisLeft={{
                  tickSize: 5,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: 'Patients',
                  legendPosition: 'middle',
                  legendOffset: -50
                }}
                enableGridY={true}
                labelSkipWidth={12}
                labelSkipHeight={12}
                enableLabel={true}
                label={d => { return displayMode === "percentage" ? (d.percentage !== undefined ? `${d.percentage}%` : "0%") : `${d.value}`; }}
                labelTextColor={"#000000"}
                labelPosition="outside"
                labelOffset={-3}
                theme={{
                  labels: {
                    text: {
                      fontSize: 11,
                      fontWeight: 700,
                      textAnchor: 'middle', dominantBaseline: 'text-before-edge',
                      dominantBaseline: 'auto'
                    }
                  }
                }}
                animate={true}
                motionConfig="gentle"
                role="application"
                ariaLabel="Risk Stratification"
              />
            </CardContent>
            <CardFooter className="p-2 flex justify-between">
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="sm" variant="outline">
                    <Maximize className="h-4 w-4 mr-2" />
                    Enlarge
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl h-[80vh]">
                  <DialogHeader>
                    <DialogTitle>Risk Stratification</DialogTitle>
                  </DialogHeader>
                  <div className="flex-1 h-[calc(80vh-120px)]">
                    <ResponsiveBar
                      data={getRiskStratificationData()}
                      keys={['value']}
                      indexBy="id"
                      margin={{ top: 70, right: 80, bottom: 140, left: 80 }}
                      padding={0.3}
                      layout="vertical"
                      colors={getRiskColors()}
                      valueScale={{ type: 'linear' }}
                      indexScale={{ type: 'band', round: true }}
                      borderColor={{ from: 'color', modifiers: [['darker', 1.6]] }}
                      axisBottom={{
                        tickSize: 5,
                        tickPadding: 25,
                        tickRotation: -35,
                        legendPosition: 'middle',
                        legendOffset: 80,
                        truncateTickAt: 0,
                        format: (value) => value // Ensure full risk level names are shown
                      }}
                      axisLeft={{
                        tickSize: 5,
                        tickPadding: 5,
                        tickRotation: 0,
                        legend: 'Patients',
                        legendPosition: 'middle',
                        legendOffset: -50
                      }}
                      enableGridY={true}
                      labelSkipWidth={12}
                      labelSkipHeight={12}
                      enableLabel={true}
                      label={d => { return displayMode === "percentage" ? (d.percentage !== undefined ? `${d.percentage}%` : "0%") : `${d.value}`; }}
                      labelTextColor={"#000000"}
                      labelPosition="outside"
                      labelOffset={-3}
                      theme={{
                        labels: {
                          text: {
                            fontSize: 11,
                            fontWeight: 700,
                            textAnchor: 'middle', dominantBaseline: 'text-before-edge',
                            dominantBaseline: 'auto'
                          }
                        }
                      }}
                      animate={true}
                      motionConfig="gentle"
                      role="application"
                      ariaLabel="Risk Stratification Enlarged"
                    />
                  </div>
                </DialogContent>
              </Dialog>
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => downloadChart('Risk Stratification', getRiskStratificationData())}
              >
                <Download className="h-4 w-4 mr-2" />
                Download Chart
              </Button>
            </CardFooter>
          </Card>
          
          {/* Chart 3: Total Population by Symptom Segment (Middle Left) */}
          <Card className="overflow-hidden">
            <CardHeader className="p-2 pb-0">
              <CardTitle className="text-sm">Total Population by Symptom Segment</CardTitle>
            </CardHeader>
            <CardContent className="p-2 h-[280px]">
              <ResponsiveBar
                data={getSymptomSegmentData()}
                keys={['value']}
                indexBy="id"
                margin={{ top: 60, right: 30, bottom: 70, left: 80 }}
                padding={0.3}
                layout="vertical"
                colors={getChartColors()}
                valueScale={{ type: 'linear' }}
                indexScale={{ type: 'band', round: true }}
                borderColor={{ from: 'color', modifiers: [['darker', 1.6]] }}
                axisBottom={{
                  tickSize: 5,
                  tickPadding: 10,
                  tickRotation: -45,
                  legendPosition: 'middle',
                  legendOffset: 50,
                  truncateTickAt: 0
                }}
                axisLeft={{
                  tickSize: 5,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: 'Count',
                  legendPosition: 'middle',
                  legendOffset: -50
                }}
                enableGridY={true}
                labelSkipWidth={12}
                labelSkipHeight={12}
                enableLabel={true}
                label={d => { return displayMode === "percentage" ? (d.percentage !== undefined ? `${d.percentage}%` : "0%") : `${d.value}`; }}
                labelTextColor={"#000000"}
                labelPosition="outside"
                labelOffset={-3}
                theme={{
                  labels: {
                    text: {
                      fontSize: 11,
                      fontWeight: 700,
                      textAnchor: 'middle', dominantBaseline: 'text-before-edge',
                      dominantBaseline: 'auto'
                    }
                  }
                }}
                animate={true}
                motionConfig="gentle"
                role="application"
                ariaLabel="Population by Symptom Segment"
              />
            </CardContent>
            <CardFooter className="p-2 flex justify-between">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Maximize className="w-4 h-4 mr-2" />
                    Enlarge
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl h-[80vh]">
                  <DialogHeader>
                    <DialogTitle>Total Population by Symptom Segment</DialogTitle>
                  </DialogHeader>
                  <div className="h-[calc(80vh-100px)]">
                    <ResponsiveBar
                      data={getSymptomSegmentData()}
                      keys={['value']}
                      indexBy="id"
                      margin={{ top: 70, right: 50, bottom: 140, left: 100 }}
                      padding={0.3}
                      layout="vertical"
                      colors={getChartColors()}
                      axisBottom={{
                        tickSize: 5,
                        tickPadding: 15,
                        tickRotation: -35,
                        legendPosition: 'middle',
                        legendOffset: 80,
                        truncateTickAt: 0
                      }}
                      axisLeft={{
                        tickSize: 5,
                        tickPadding: 5,
                        tickRotation: 0,
                        legend: 'Count',
                        legendPosition: 'middle',
                        legendOffset: -60
                      }}
                      enableGridY={true}
                      labelSkipWidth={12}
                      labelSkipHeight={12}
                      enableLabel={true}
                      label={d => { return displayMode === "percentage" ? (d.percentage !== undefined ? `${d.percentage}%` : "0%") : `${d.value}`; }}
                      labelTextColor={"#000000"}
                      labelPosition="outside"
                      labelOffset={-3}
                      theme={{
                        labels: {
                          text: {
                            fontSize: 11,
                            fontWeight: 700,
                            textAnchor: 'middle', dominantBaseline: 'text-before-edge',
                            dominantBaseline: 'auto'
                          }
                        }
                      }}
                      animate={true}
                    />
                  </div>
                </DialogContent>
              </Dialog>
              
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => downloadChart('Symptom_Segment', getSymptomSegmentData())}
              >
                <Download className="w-4 h-4 mr-2" />
                Download Chart
              </Button>
            </CardFooter>
          </Card>
          
          {/* Chart 2: Total Population by Diagnosis */}
          <Card className="overflow-hidden">
            <CardHeader className="p-2 pb-0">
              <CardTitle className="text-sm">Total Population by Diagnosis</CardTitle>
            </CardHeader>
            <CardContent className="p-2 h-[280px]">
              <ResponsiveBar
                data={getDiagnosisData()}
                keys={['value']}
                indexBy="id"
                margin={{ top: 60, right: 30, bottom: 70, left: 80 }}
                padding={0.3}
                layout="vertical"
                colors={getChartColors()}
                valueScale={{ type: 'linear' }}
                indexScale={{ type: 'band', round: true }}
                borderColor={{ from: 'color', modifiers: [['darker', 1.6]] }}
                axisBottom={{
                  tickSize: 5,
                  tickPadding: 10,
                  tickRotation: -45,
                  legendPosition: 'middle',
                  legendOffset: 50,
                  truncateTickAt: 0
                }}
                axisLeft={{
                  tickSize: 5,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: 'Count',
                  legendPosition: 'middle',
                  legendOffset: -50
                }}
                enableGridY={true}
                labelSkipWidth={12}
                labelSkipHeight={12}
                enableLabel={true}
                label={d => { return displayMode === "percentage" ? (d.percentage !== undefined ? `${d.percentage}%` : "0%") : `${d.value}`; }}
                labelTextColor={"#000000"}
                labelPosition="outside"
                labelOffset={-3}
                theme={{
                  labels: {
                    text: {
                      fontSize: 11,
                      fontWeight: 700,
                      textAnchor: 'middle', dominantBaseline: 'text-before-edge',
                      dominantBaseline: 'auto'
                    }
                  }
                }}
                animate={true}
                motionConfig="gentle"
                role="application"
                ariaLabel="Population by Diagnosis"
              />
            </CardContent>
            <CardFooter className="p-2 flex justify-between">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Maximize className="w-4 h-4 mr-2" />
                    Enlarge
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl h-[80vh]">
                  <DialogHeader>
                    <DialogTitle>Total Population by Diagnosis</DialogTitle>
                  </DialogHeader>
                  <div className="h-[calc(80vh-100px)]">
                    <ResponsiveBar
                      data={getDiagnosisData()}
                      keys={['value']}
                      indexBy="id"
                      margin={{ top: 70, right: 50, bottom: 140, left: 100 }}
                      padding={0.3}
                      layout="vertical"
                      colors={getChartColors()}
                      axisBottom={{
                        tickSize: 5,
                        tickPadding: 15,
                        tickRotation: -35,
                        legendPosition: 'middle',
                        legendOffset: 80,
                        truncateTickAt: 0
                      }}
                      axisLeft={{
                        tickSize: 5,
                        tickPadding: 5,
                        tickRotation: 0,
                        legend: 'Count',
                        legendPosition: 'middle',
                        legendOffset: -60
                      }}
                      enableGridY={true}
                      labelSkipWidth={12}
                      labelSkipHeight={12}
                      enableLabel={true}
                      label={d => { return displayMode === "percentage" ? (d.percentage !== undefined ? `${d.percentage}%` : "0%") : `${d.value}`; }}
                      labelTextColor={"#000000"}
                      labelPosition="outside"
                      labelOffset={-3}
                      theme={{
                        labels: {
                          text: {
                            fontSize: 11,
                            fontWeight: 700,
                            textAnchor: 'middle', dominantBaseline: 'text-before-edge',
                            dominantBaseline: 'auto'
                          }
                        }
                      }}
                      animate={true}
                    />
                  </div>
                </DialogContent>
              </Dialog>
              
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => downloadChart('Diagnosis', getDiagnosisData())}
              >
                <Download className="w-4 h-4 mr-2" />
                Download Chart
              </Button>
            </CardFooter>
          </Card>
          
          {/* Chart 3: Total Population by Symptom ID */}
          <Card className="overflow-hidden">
            <CardHeader className="p-2 pb-0">
              <CardTitle className="text-sm">Total Population by Symptom ID</CardTitle>
            </CardHeader>
            <CardContent className="p-2 h-[280px]">
              <ResponsiveBar
                data={getSymptomIDData()}
                keys={['value']}
                indexBy="id"
                margin={{ top: 60, right: 30, bottom: 70, left: 80 }}
                padding={0.3}
                layout="vertical"
                colors={getChartColors()}
                valueScale={{ type: 'linear' }}
                indexScale={{ type: 'band', round: true }}
                borderColor={{ from: 'color', modifiers: [['darker', 1.6]] }}
                axisBottom={{
                  tickSize: 5,
                  tickPadding: 10,
                  tickRotation: -45,
                  legendPosition: 'middle',
                  legendOffset: 50,
                  truncateTickAt: 0
                }}
                axisLeft={{
                  tickSize: 5,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: 'Count',
                  legendPosition: 'middle',
                  legendOffset: -50
                }}
                enableGridY={true}
                labelSkipWidth={12}
                labelSkipHeight={12}
                enableLabel={true}
                label={d => { return displayMode === "percentage" ? (d.percentage !== undefined ? `${d.percentage}%` : "0%") : `${d.value}`; }}
                labelTextColor={"#000000"}
                animate={true}
                motionConfig="gentle"
                role="application"
                ariaLabel="Population by Symptom ID"
                // Chart ref will be captured using DOM APIs instead
              />
            </CardContent>
            <CardFooter className="p-2 flex justify-between">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Maximize className="w-4 h-4 mr-2" />
                    Enlarge
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl h-[80vh]">
                  <DialogHeader>
                    <DialogTitle>Total Population by Symptom ID</DialogTitle>
                  </DialogHeader>
                  <div className="h-[calc(80vh-100px)]">
                    <ResponsiveBar
                      data={getSymptomIDData()}
                      keys={['value']}
                      indexBy="id"
                      margin={{ top: 70, right: 50, bottom: 100, left: 100 }}
                      padding={0.3}
                      layout="vertical"
                      colors={getChartColors()}
                      axisBottom={{
                        tickSize: 5,
                        tickPadding: 10,
                        tickRotation: -45,
                        legendPosition: 'middle',
                        legendOffset: 60,
                        truncateTickAt: 0
                      }}
                      axisLeft={{
                        tickSize: 5,
                        tickPadding: 5,
                        tickRotation: 0,
                        legend: 'Count',
                        legendPosition: 'middle',
                        legendOffset: -60
                      }}
                      enableGridY={true}
                      labelSkipWidth={12}
                      labelSkipHeight={12}
                      enableLabel={true}
                      label={d => { return displayMode === "percentage" ? (d.percentage !== undefined ? `${d.percentage}%` : "0%") : `${d.value}`; }}
                      labelTextColor={"#000000"}
                      animate={true}
                    />
                  </div>
                </DialogContent>
              </Dialog>
              
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => downloadChart('Symptom_ID', getSymptomIDData())}
              >
                <Download className="w-4 h-4 mr-2" />
                Download Chart
              </Button>
            </CardFooter>
          </Card>
          
          {/* Chart 4: Total Population by Diagnostic Category */}
          <Card className="overflow-hidden">
            <CardHeader className="p-2 pb-0">
              <CardTitle className="text-sm">Total Population by Diagnostic Category</CardTitle>
            </CardHeader>
            <CardContent className="p-2 h-[280px]">
              <ResponsiveBar
                data={getDiagnosticCategoryData()}
                keys={['value']}
                indexBy="id"
                margin={{ top: 60, right: 30, bottom: 70, left: 80 }}
                padding={0.3}
                layout="vertical"
                colors={getChartColors()}
                valueScale={{ type: 'linear' }}
                indexScale={{ type: 'band', round: true }}
                borderColor={{ from: 'color', modifiers: [['darker', 1.6]] }}
                axisBottom={{
                  tickSize: 5,
                  tickPadding: 10,
                  tickRotation: -45,
                  legendPosition: 'middle',
                  legendOffset: 50,
                  truncateTickAt: 0
                }}
                axisLeft={{
                  tickSize: 5,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: 'Count',
                  legendPosition: 'middle',
                  legendOffset: -50
                }}
                enableGridY={true}
                labelSkipWidth={12}
                labelSkipHeight={12}
                enableLabel={true}
                label={d => { return displayMode === "percentage" ? (d.percentage !== undefined ? `${d.percentage}%` : "0%") : `${d.value}`; }}
                labelTextColor={"#000000"}
                animate={true}
                motionConfig="gentle"
                role="application"
                ariaLabel="Population by Diagnostic Category"
                // Chart ref will be captured using DOM APIs instead
              />
            </CardContent>
            <CardFooter className="p-2 flex justify-between">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Maximize className="w-4 h-4 mr-2" />
                    Enlarge
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl h-[80vh]">
                  <DialogHeader>
                    <DialogTitle>Total Population by Diagnostic Category</DialogTitle>
                  </DialogHeader>
                  <div className="h-[calc(80vh-100px)]">
                    <ResponsiveBar
                      data={getDiagnosticCategoryData()}
                      keys={['value']}
                      indexBy="id"
                      margin={{ top: 70, right: 50, bottom: 100, left: 100 }}
                      padding={0.3}
                      layout="vertical"
                      colors={getChartColors()}
                      axisBottom={{
                        tickSize: 5,
                        tickPadding: 10,
                        tickRotation: -45,
                        legendPosition: 'middle',
                        legendOffset: 60,
                        truncateTickAt: 0
                      }}
                      axisLeft={{
                        tickSize: 5,
                        tickPadding: 5,
                        tickRotation: 0,
                        legend: 'Count',
                        legendPosition: 'middle',
                        legendOffset: -60
                      }}
                      enableGridY={true}
                      labelSkipWidth={12}
                      labelSkipHeight={12}
                      enableLabel={true}
                      label={d => { return displayMode === "percentage" ? (d.percentage !== undefined ? `${d.percentage}%` : "0%") : `${d.value}`; }}
                      labelTextColor={"#000000"}
                      animate={true}
                    />
                  </div>
                </DialogContent>
              </Dialog>
              
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => downloadChart('Diagnostic_Category', getDiagnosticCategoryData())}
              >
                <Download className="w-4 h-4 mr-2" />
                Download Chart
              </Button>
            </CardFooter>
          </Card>
        </div>
        
        {/* Population Health Filters Section - Compact */}
        <div className="mt-4 space-y-3">
          <h3 className="text-base font-semibold text-gray-800">Apply Population Health Filters</h3>
          
          <div className="space-y-2">
            {/* First filter level - derived from the dataset - more compact */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <div>
                <Label htmlFor="symptomSegments" className="block text-sm font-medium text-gray-700 mb-1">
                  Select Symptom Segment(s):
                </Label>
                <Select>
                  <SelectTrigger id="symptomSegments" className="w-full">
                    <SelectValue placeholder="Choose an option" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Segments</SelectItem>
                    <SelectItem value="withdrawal_symptoms">Withdrawal symptoms</SelectItem>
                    <SelectItem value="loss_of_appetite">Loss of appetite</SelectItem>
                    <SelectItem value="anxiety">Anxiety</SelectItem>
                    <SelectItem value="increased_appetite">Increased appetite</SelectItem>
                    <SelectItem value="rage">Used rage weekly in the past 12 months</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="diagnosis" className="block text-sm font-medium text-gray-700 mb-1">
                  Select Diagnosis(s):
                </Label>
                <Select>
                  <SelectTrigger id="diagnosis" className="w-full">
                    <SelectValue placeholder="Choose an option" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Diagnoses</SelectItem>
                    <SelectItem value="mdd">Major Depressive Disorder</SelectItem>
                    <SelectItem value="hud">Hallucinogen Use Disorder</SelectItem>
                    <SelectItem value="pdd">Persistent Depressive Disorder</SelectItem>
                    <SelectItem value="ptsd">Post-Traumatic Stress Disorder</SelectItem>
                    <SelectItem value="rdd">Recurrent Depressive Disorder</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="diagnosticCategory" className="block text-sm font-medium text-gray-700 mb-1">
                  Select Diagnostic Category(s):
                </Label>
                <Select>
                  <SelectTrigger id="diagnosticCategory" className="w-full">
                    <SelectValue placeholder="Choose an option" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="depressive">Depressive Disorders</SelectItem>
                    <SelectItem value="substance">Substance Use Disorders</SelectItem>
                    <SelectItem value="anxiety">Anxiety Disorders</SelectItem>
                    <SelectItem value="bipolar">Bipolar Disorders</SelectItem>
                    <SelectItem value="other">Other/Unknown Substance Use Disorder</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="symptomId" className="block text-sm font-medium text-gray-700 mb-1">
                  Select Symptom ID(s):
                </Label>
                <Select>
                  <SelectTrigger id="symptomId" className="w-full">
                    <SelectValue placeholder="Choose an option" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Symptom IDs</SelectItem>
                    <SelectItem value="no_z">No Z Code</SelectItem>
                    <SelectItem value="f4802">F48.0.2</SelectItem>
                    <SelectItem value="f19214">F19.21.44</SelectItem>
                    <SelectItem value="f1615">F16.1.5</SelectItem>
                    <SelectItem value="f1614">F16.1.04</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex items-center justify-between pt-2 border-t border-gray-200">
              <div className="text-sm text-gray-600">
                Total records after filtering: <span className="font-medium">4608</span>
              </div>
              
              <Button
                variant="outline"
                className="flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                Download Filtered Results
              </Button>
            </div>
          </div>
        </div>
        
        {/* Additional Filters for Deeper Analysis - Compact */}
        <div className="mt-4 space-y-3">
          <h3 className="text-base font-semibold text-gray-800">Additional Filters for Deeper Analysis</h3>
          
          <div className="space-y-2">
            <p className="text-gray-600">Select Additional Characteristics to Visualize:</p>
            
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  className="w-full justify-between"
                >
                  {selectedFilters.length > 0
                    ? `${selectedFilters.length} option${selectedFilters.length > 1 ? 's' : ''} selected`
                    : "Choose an option"}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-full p-0">
                <Command>
                  <CommandInput placeholder="Search characteristics..." />
                  <CommandEmpty>No characteristic found.</CommandEmpty>
                  <CommandGroup>
                    {filterOptions.map((option) => (
                      <CommandItem
                        key={option.value}
                        value={option.value}
                        onSelect={() => {
                          const newSelection = selectedFilters.includes(option.value)
                            ? selectedFilters.filter(item => item !== option.value)
                            : [...selectedFilters, option.value];
                          setSelectedFilters(newSelection);
                        }}
                      >
                        <Check
                          className={cn(
                            "mr-2 h-4 w-4",
                            selectedFilters.includes(option.value) ? "opacity-100" : "opacity-0"
                          )}
                        />
                        {option.label}
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </Command>
              </PopoverContent>
            </Popover>
            
            <div className="flex justify-between items-center mt-4">
              <div className="space-x-2">
                {selectedFilters.length > 0 && (
                  <Button 
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedFilters([])}
                  >
                    Reset Filters
                  </Button>
                )}
                
                <Button 
                  variant="default"
                  size="sm"
                  className="bg-blue-600 hover:bg-blue-700"
                  onClick={() => {
                    console.log("Running visualizations with filters:", selectedFilters);
                    setShowFilterVisualizations(true);
                  }}
                >
                  Run Visualizations
                </Button>
              </div>
              
              <Button 
                variant="outline" 
                onClick={() => {
                  const allData = {
                    symptomSegments: getSymptomSegmentData(),
                    diagnoses: getDiagnosisData(),
                    symptomIds: getSymptomIDData(),
                    diagnosticCategories: getDiagnosticCategoryData()
                  };
                  
                  // Create a downloadable JSON file
                  const dataStr = JSON.stringify(allData, null, 2);
                  const dataBlob = new Blob([dataStr], { type: 'application/json' });
                  const dataUrl = URL.createObjectURL(dataBlob);
                  
                  const downloadLink = document.createElement('a');
                  downloadLink.href = dataUrl;
                  downloadLink.download = 'population_health_data.json';
                  document.body.appendChild(downloadLink);
                  downloadLink.click();
                  document.body.removeChild(downloadLink);
                }}
              >
                <Download className="w-4 h-4 mr-2" />
                Download All Charts Data
              </Button>
            </div>
          </div>
          
          {/* Filter Visualizations - More Compact */}
          {showFilterVisualizations && selectedFilters.length > 0 && (
            <div className="mt-4 space-y-4">
              <div className="flex justify-between items-center border-b pb-1">
                <h3 className="text-base font-semibold text-gray-800">Filter Visualizations</h3>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="h-7 px-2 text-xs"
                  onClick={() => setShowFilterVisualizations(false)}
                >
                  Hide Visualizations
                </Button>
              </div>
              
              {selectedFilters.map((filter) => {
                const { barChartData, pieChartData } = getFilterVisualizationData(filter);
                const filterLabel = filterOptions.find(opt => opt.value === filter)?.label || filter;
                
                return (
                  <div key={filter} className="space-y-4">
                    <h4 className="text-base font-medium text-gray-700">{filterLabel} Distribution</h4>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Bar Chart */}
                      <Card className="overflow-hidden">
                        <CardHeader className="p-2 pb-0">
                          <CardTitle className="text-sm">{filterLabel} Count</CardTitle>
                        </CardHeader>
                        <CardContent className="p-2 h-[280px]">
                          <ResponsiveBar
                            data={barChartData}
                            keys={['value']}
                            indexBy="category"
                            margin={{ top: 30, right: 30, bottom: 70, left: 60 }}
                            padding={0.3}
                            layout="vertical"
                            colors={colorSettings.isCustomPalette && colorSettings.colors ? colorSettings.colors : getChartColors()}
                            axisBottom={{
                              tickSize: 5,
                              tickPadding: 10,
                              tickRotation: -45,
                              legendPosition: 'middle',
                              legendOffset: 50,
                              truncateTickAt: 0
                            }}
                            axisLeft={{
                              tickSize: 5,
                              tickPadding: 5,
                              tickRotation: 0,
                              legend: 'Count',
                              legendPosition: 'middle',
                              legendOffset: -40
                            }}
                            enableGridY={true}
                            labelSkipWidth={12}
                            labelSkipHeight={12}
                            enableLabel={true}
                            label={d => { return displayMode === "percentage" ? (d.percentage !== undefined ? `${d.percentage}%` : "0%") : `${d.value}`; }}
                            labelTextColor={"#000000"}
                            animate={true}
                            motionConfig="gentle"
                          />
                        </CardContent>
                        <CardFooter className="p-2 flex justify-end">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => {
                              const dataStr = JSON.stringify(barChartData, null, 2);
                              const dataBlob = new Blob([dataStr], { type: 'application/json' });
                              const dataUrl = URL.createObjectURL(dataBlob);
                              
                              const downloadLink = document.createElement('a');
                              downloadLink.href = dataUrl;
                              downloadLink.download = `${filterLabel.replace(/\s+/g, '_')}_count.json`;
                              document.body.appendChild(downloadLink);
                              downloadLink.click();
                              document.body.removeChild(downloadLink);
                            }}
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Download Data
                          </Button>
                        </CardFooter>
                      </Card>
                      
                      {/* Pie Chart */}
                      <Card className="overflow-hidden">
                        <CardHeader className="p-2 pb-0">
                          <CardTitle className="text-sm">{filterLabel} Percentage</CardTitle>
                        </CardHeader>
                        <CardContent className="p-2 h-[280px]">
                          <ResponsivePie
                            data={pieChartData}
                            margin={{ top: 40, right: 80, bottom: 40, left: 80 }}
                            innerRadius={0.5}
                            padAngle={0.7}
                            cornerRadius={3}
                            activeOuterRadiusOffset={8}
                            borderWidth={1}
                            colors={getPieChartColors()}
                            borderColor={{
                              from: 'color',
                              modifiers: [['darker', 0.2]]
                            }}
                            arcLinkLabelsSkipAngle={10}
                            arcLinkLabelsTextColor="#333333"
                            arcLinkLabelsThickness={2}
                            arcLinkLabelsColor={{ from: 'color' }}
                            arcLabelsSkipAngle={10}
                            arcLabelsTextColor={{
                              from: 'color',
                              modifiers: [['darker', 2]]
                            }}
                            valueFormat={(value) => `${value}%`}
                            legends={[
                              {
                                anchor: 'bottom',
                                direction: 'row',
                                justify: false,
                                translateX: 0,
                                translateY: 56,
                                itemsSpacing: 0,
                                itemWidth: 100,
                                itemHeight: 18,
                                itemTextColor: '#999',
                                itemDirection: 'left-to-right',
                                itemOpacity: 1,
                                symbolSize: 18,
                                symbolShape: 'circle',
                                effects: [
                                  {
                                    on: 'hover',
                                    style: {
                                      itemTextColor: '#333'
                                    }
                                  }
                                ]
                              }
                            ]}
                          />
                        </CardContent>
                        <CardFooter className="p-2 flex justify-end">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => {
                              const dataStr = JSON.stringify(pieChartData, null, 2);
                              const dataBlob = new Blob([dataStr], { type: 'application/json' });
                              const dataUrl = URL.createObjectURL(dataBlob);
                              
                              const downloadLink = document.createElement('a');
                              downloadLink.href = dataUrl;
                              downloadLink.download = `${filterLabel.replace(/\s+/g, '_')}_percentage.json`;
                              document.body.appendChild(downloadLink);
                              downloadLink.click();
                              document.body.removeChild(downloadLink);
                            }}
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Download Data
                          </Button>
                        </CardFooter>
                      </Card>
                    </div>
                    
                    {/* Additional Visualizations: Heatmap and Circle Packing */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                      {/* Heatmap */}
                      <Card className="overflow-hidden">
                        <CardHeader className="p-2 pb-0">
                          <CardTitle className="text-sm">{filterLabel} Heatmap</CardTitle>
                        </CardHeader>
                        <CardContent className="p-2 h-[280px]">
                          {/* @ts-ignore */}
                          <ResponsiveHeatMap
                            data={filter === 'gender' ? 
                              // For gender filter, show actual symptom data by gender
                              [
                                {
                                  id: 'Housing Insecurity',
                                  data: barChartData.map(item => ({
                                    x: item.category,
                                    y: 1,
                                    value: Math.round(item.value * (Math.random() * 0.2 + 0.3))
                                  }))
                                },
                                {
                                  id: 'Food Insecurity',
                                  data: barChartData.map(item => ({
                                    x: item.category,
                                    y: 2,
                                    value: Math.round(item.value * (Math.random() * 0.2 + 0.4))
                                  }))
                                },
                                {
                                  id: 'Transportation',
                                  data: barChartData.map(item => ({
                                    x: item.category,
                                    y: 3,
                                    value: Math.round(item.value * (Math.random() * 0.2 + 0.2))
                                  }))
                                },
                                {
                                  id: 'Financial Strain',
                                  data: barChartData.map(item => ({
                                    x: item.category,
                                    y: 4,
                                    value: Math.round(item.value * (Math.random() * 0.2 + 0.5))
                                  }))
                                },
                                {
                                  id: 'Education Access',
                                  data: barChartData.map(item => ({
                                    x: item.category,
                                    y: 5,
                                    value: Math.round(item.value * (Math.random() * 0.2 + 0.15))
                                  }))
                                }
                              ] 
                              : 
                              // Default implementation for other filters
                              [
                                {
                                  id: 'Housing Status',
                                  data: barChartData.map(item => ({
                                    x: item.category,
                                    y: 1,
                                    value: item.value * 0.8
                                  }))
                                },
                                {
                                  id: 'Food Status',
                                  data: barChartData.map(item => ({
                                    x: item.category,
                                    y: 2,
                                    value: item.value * 0.6
                                  }))
                                },
                                {
                                  id: 'Financial Status',
                                  data: barChartData.map(item => ({
                                    x: item.category,
                                    y: 3,
                                    value: item.value
                                  }))
                                }
                              ]
                            }
                            margin={{ top: 60, right: 30, bottom: 60, left: 90 }}
                            valueFormat=">-.2s"
                            axisTop={{
                              tickSize: 5,
                              tickPadding: 5,
                              tickRotation: -45,
                              legend: '',
                              legendOffset: 46
                            }}
                            axisRight={null}
                            axisBottom={{
                              tickSize: 5,
                              tickPadding: 5,
                              tickRotation: -45,
                              legend: filterLabel,
                              legendPosition: 'middle',
                              legendOffset: 36
                            }}
                            axisLeft={{
                              tickSize: 5,
                              tickPadding: 5,
                              tickRotation: 0,
                              legend: 'HRSN Category',
                              legendPosition: 'middle',
                              legendOffset: -72,
                              format: (value) => {
                                if (filter === 'gender') {
                                  const labels = ['Housing Insecurity', 'Food Insecurity', 'Transportation', 'Financial Strain', 'Education Access'];
                                  return labels[value-1] || value.toString();
                                }
                                return value.toString();
                              }
                            }}
                            colors={colorSettings.isCustomPalette ? 
                              // For custom palettes like viridis, use proper heatmap coloring
                              { type: 'sequential', scheme: 'YlGnBu' } as any :
                              // For standard themes, map to appropriate sequential schemes
                              { type: 'sequential', scheme: 
                                currentTheme === 'vivid' ? 'spectral' :
                                currentTheme === 'dark' ? 'greys' :
                                currentTheme === 'pastel' ? 'YlOrRd' :
                                currentTheme === 'muted' ? 'BuPu' :
                                currentTheme === 'light' ? 'blues' : 'YlGnBu'
                              } as any}
                            emptyColor="#eeeeee"
                            borderColor={{
                              from: 'color',
                              modifiers: [['darker', 0.4]]
                            }}
                            animate={true}
                            motionConfig="gentle"
                            hoverTarget="cell"
                            // Removed non-standard props to fix TypeScript errors
                            labelTextColor={{
                              from: 'color',
                              modifiers: [['darker', 2]]
                            }}
                          />
                        </CardContent>
                        <CardFooter className="p-2 flex justify-end">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => {
                              const dataStr = JSON.stringify(barChartData, null, 2);
                              const dataBlob = new Blob([dataStr], { type: 'application/json' });
                              const dataUrl = URL.createObjectURL(dataBlob);
                              
                              const downloadLink = document.createElement('a');
                              downloadLink.href = dataUrl;
                              downloadLink.download = `${filterLabel.replace(/\s+/g, '_')}_heatmap.json`;
                              document.body.appendChild(downloadLink);
                              downloadLink.click();
                              document.body.removeChild(downloadLink);
                            }}
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Download Data
                          </Button>
                        </CardFooter>
                      </Card>
                      
                      {/* Circle Packing */}
                      <Card className="overflow-hidden">
                        <CardHeader className="p-2 pb-0">
                          <CardTitle className="text-sm">{filterLabel} Distribution</CardTitle>
                        </CardHeader>
                        <CardContent className="p-2 h-[280px]">
                          <ResponsiveCirclePacking
                            data={{
                              name: filterLabel,
                              children: pieChartData.map(item => ({
                                name: `${item.label} (${item.value}%)`,
                                value: item.value
                              }))
                            }}
                            margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
                            id="name"
                            value="value"
                            colors={getPieChartColors()}
                            childColor={{ from: 'color', modifiers: [['brighter', 0.4]] }}
                            padding={4}
                            enableLabels={true}
                            labelsFilter={label => label.node.height === 0}
                            labelsSkipRadius={8}
                            labelTextColor={{
                              from: 'color',
                              modifiers: [['darker', 2]]
                            }}
                            tooltip={({ id, value, color }) => (
                              <div
                                style={{
                                  padding: 12,
                                  background: '#fff',
                                  border: `1px solid ${color}`,
                                  borderRadius: '4px'
                                }}
                              >
                                <strong>{id}</strong>
                                <br />
                                <strong>Percentage: {value}%</strong>
                              </div>
                            )}
                            borderWidth={1}
                            borderColor={{ from: 'color', modifiers: [['darker', 0.5]] }}
                            animate={true}
                            motionConfig="gentle"
                          />
                        </CardContent>
                        <CardFooter className="p-2 flex justify-end">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => {
                              const dataStr = JSON.stringify(pieChartData, null, 2);
                              const dataBlob = new Blob([dataStr], { type: 'application/json' });
                              const dataUrl = URL.createObjectURL(dataBlob);
                              
                              const downloadLink = document.createElement('a');
                              downloadLink.href = dataUrl;
                              downloadLink.download = `${filterLabel.replace(/\s+/g, '_')}_packing.json`;
                              document.body.appendChild(downloadLink);
                              downloadLink.click();
                              document.body.removeChild(downloadLink);
                            }}
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Download Data
                          </Button>
                        </CardFooter>
                      </Card>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
  );
}