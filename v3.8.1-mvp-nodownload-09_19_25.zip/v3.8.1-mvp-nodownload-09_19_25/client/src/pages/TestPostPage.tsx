import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';

export default function TestPostPage() {
  const [results, setResults] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const addResult = (message: string, success: boolean) => {
    const timestamp = new Date().toISOString();
    const prefix = success ? '✅' : '❌';
    setResults(prev => [...prev, `[${timestamp}] ${prefix} ${message}`]);
  };

  const testSimplePost = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/test-upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ test: 'simple' })
      });
      
      if (response.ok) {
        const data = await response.json();
        addResult(`Simple POST SUCCESS: ${JSON.stringify(data)}`, true);
      } else {
        addResult(`Simple POST failed with status ${response.status}`, false);
      }
    } catch (error) {
      addResult(`Simple POST error: ${error}`, false);
    }
    setLoading(false);
  };

  const testFormData = async () => {
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('test', 'formdata');
      formData.append('timestamp', Date.now().toString());
      
      const response = await fetch('/api/test-upload', {
        method: 'POST',
        body: formData
      });
      
      if (response.ok) {
        const data = await response.json();
        addResult(`FormData POST SUCCESS: ${JSON.stringify(data)}`, true);
      } else {
        addResult(`FormData POST failed with status ${response.status}`, false);
      }
    } catch (error) {
      addResult(`FormData POST error: ${error}`, false);
    }
    setLoading(false);
  };

  const testUploadEndpoint = async () => {
    setLoading(true);
    try {
      const formData = new FormData();
      const blob = new Blob(['test,data\n1,2'], { type: 'text/csv' });
      formData.append('file', blob, 'test.csv');
      
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        addResult(`Upload endpoint SUCCESS: ${JSON.stringify(data)}`, true);
      } else if (response.status === 401) {
        addResult(`Upload endpoint requires authentication (401) - request reached server!`, true);
      } else {
        addResult(`Upload endpoint failed with status ${response.status}`, false);
      }
    } catch (error) {
      addResult(`Upload endpoint error: ${error}`, false);
    }
    setLoading(false);
  };

  const testWithXHR = async () => {
    setLoading(true);
    return new Promise<void>((resolve) => {
      const xhr = new XMLHttpRequest();
      
      xhr.onload = () => {
        if (xhr.status === 200) {
          addResult(`XMLHttpRequest SUCCESS: ${xhr.responseText}`, true);
        } else {
          addResult(`XMLHttpRequest failed with status ${xhr.status}`, false);
        }
        setLoading(false);
        resolve();
      };
      
      xhr.onerror = () => {
        addResult(`XMLHttpRequest network error`, false);
        setLoading(false);
        resolve();
      };
      
      xhr.open('POST', '/api/test-upload');
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.send(JSON.stringify({ test: 'xhr' }));
    });
  };

  const clearResults = () => {
    setResults([]);
  };

  return (
    <div className="container mx-auto p-8">
      <Card>
        <CardHeader>
          <CardTitle>POST Request Test Dashboard</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Button 
                onClick={testSimplePost} 
                disabled={loading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {loading ? <Loader2 className="animate-spin" /> : 'Test Simple POST'}
              </Button>
              
              <Button 
                onClick={testFormData} 
                disabled={loading}
                className="bg-green-600 hover:bg-green-700"
              >
                {loading ? <Loader2 className="animate-spin" /> : 'Test FormData'}
              </Button>
              
              <Button 
                onClick={testUploadEndpoint} 
                disabled={loading}
                className="bg-purple-600 hover:bg-purple-700"
              >
                {loading ? <Loader2 className="animate-spin" /> : 'Test Upload'}
              </Button>
              
              <Button 
                onClick={testWithXHR} 
                disabled={loading}
                className="bg-orange-600 hover:bg-orange-700"
              >
                {loading ? <Loader2 className="animate-spin" /> : 'Test XMLHttpRequest'}
              </Button>
            </div>

            <Button 
              onClick={clearResults} 
              variant="outline"
              className="w-full"
            >
              Clear Results
            </Button>

            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Test Results:</h3>
              {results.length === 0 ? (
                <p className="text-gray-500">No tests run yet. Click a button above to test.</p>
              ) : (
                <div className="space-y-1 font-mono text-sm">
                  {results.map((result, index) => (
                    <div 
                      key={index}
                      className={result.includes('✅') ? 'text-green-700' : 'text-red-700'}
                    >
                      {result}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}