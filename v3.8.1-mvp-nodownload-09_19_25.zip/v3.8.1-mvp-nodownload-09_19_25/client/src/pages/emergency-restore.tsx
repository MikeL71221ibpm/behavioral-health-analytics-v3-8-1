import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { InfoIcon } from "lucide-react";

export default function EmergencyRestore() {
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(false);

  const restoreUsers = async () => {
    setLoading(true);
    setStatus("Starting user restoration...");
    
    try {
      const res = await fetch("/api/emergency-migrate-users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      
      const data = await res.json();
      
      if (res.ok) {
        setStatus(data.details?.join('\n') || data.message);
        
        // Show success and redirect after delay
        setTimeout(() => {
          window.location.href = "/auth";
        }, 5000);
      } else {
        setStatus(`❌ Error: ${data.error || data.message}`);
      }
    } catch (err) {
      setStatus(`❌ Error restoring users: ${err}`);
    }
    
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Emergency User Restoration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            This will restore critical user accounts to the production database.
          </p>
          
          <Alert className="border-yellow-200 bg-yellow-50">
            <InfoIcon className="h-4 w-4 text-yellow-800" />
            <AlertDescription className="text-yellow-800">
              <strong>Important:</strong> After restoration, all users will have the temporary password:
              <br />
              <code className="bg-yellow-100 px-2 py-1 rounded text-lg font-bold">TempPass123!</code>
              <br />
              <br />
              You should change your password after logging in.
            </AlertDescription>
          </Alert>
          
          <Button 
            onClick={restoreUsers} 
            disabled={loading}
            className="w-full"
          >
            {loading ? "Restoring Users..." : "Restore Users Now"}
          </Button>

          {status && (
            <pre className="mt-4 p-4 bg-muted rounded text-xs whitespace-pre-wrap">
              {status}
            </pre>
          )}
        </CardContent>
      </Card>
    </div>
  );
}